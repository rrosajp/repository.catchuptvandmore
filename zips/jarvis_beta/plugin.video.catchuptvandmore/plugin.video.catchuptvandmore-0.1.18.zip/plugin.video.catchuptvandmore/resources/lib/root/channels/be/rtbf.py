# -*- coding: utf-8 -*-
"""
    Catch-up TV & More
    Copyright (C) 2017  SylvainCecchetto

    This file is part of Catch-up TV & More.

    Catch-up TV & More is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Catch-up TV & More is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with Catch-up TV & More; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""

import json
import re
import time
from bs4 import BeautifulSoup as bs
from resources.lib import utils
from resources.lib import resolver
from resources.lib import common

# TO DO
# Add geoblock (info in JSON)
# Add Quality Mode


URL_EMISSIONS_AUVIO = 'https://www.rtbf.be/auvio/emissions'

URL_JSON_EMISSION_BY_ID = 'https://www.rtbf.be/api/media/video?' \
                          'method=getVideoListByEmissionOrdered&args[]=%s'
# emission_id

URL_CATEGORIES = 'https://www.rtbf.be/news/api/menu?site=media'

URL_SUB_CATEGORIES = 'https://www.rtbf.be/news/api/block?data[0][uuid]=%s&data[0][type]=widget&data[0][settings][id]=%s'
# data-uuid and part of data-uuid

URL_VIDEO_BY_ID = 'https://www.rtbf.be/auvio/embed/media?id=%s&autoplay=1'
# Video Id

URL_ROOT_IMAGE_RTBF = 'https://ds1.static.rtbf.be'

URL_JSON_LIVE = 'https://www.rtbf.be/api/partner/generic/live/' \
                'planninglist?target_site=media&origin_site=media&category_id=0&' \
                'start_date=&offset=0&limit=15&partner_key=%s&v=8'
# partener_key

URL_ROOT_LIVE = 'https://www.rtbf.be/auvio/direct#/'


def channel_entry(params):
    """Entry function of the module"""
    if 'replay_entry' == params.next:
        params.next = "list_shows_1"
        return list_shows(params)
    elif 'list_shows' in params.next:
        return list_shows(params)
    elif 'list_videos' in params.next:
        return list_videos(params)
    elif 'play' in params.next:
        return get_video_url(params)
    else:
        return None


def get_partener_key(params):
    """Get Partener Key"""
    file_path_root_live = utils.download_catalog(
        URL_ROOT_LIVE,
        '%s_root_live.html' % params.channel_name,
    )
    html_root_live = open(file_path_root_live).read()

    list_js_files = re.compile(
        r'<script type="text\/javascript" src="(.*?)">'
    ).findall(html_root_live)

    partener_key_value = ''
    i = 0

    for js_file in list_js_files:
        # Get partener key
        file_path_js = utils.download_catalog(
            js_file,
            '%s_partener_key_%s.js' % (params.channel_name, str(i)),
        )
        partener_key_js = open(file_path_js).read()

        partener_key = re.compile(
            'partner_key: \'(.+?)\'').findall(partener_key_js)
        if len(partener_key) > 0:
            partener_key_value = partener_key[0]
        i = i + 1

    return partener_key_value


def format_hours(date):
    """Format hours"""
    date_list = date.split('T')
    date_hour = date_list[1][:5]
    return date_hour


def format_day(date):
    """Format day"""
    date_list = date.split('T')
    date_dmy = date_list[0].replace('-', '/')
    return date_dmy


@common.PLUGIN.mem_cached(common.CACHE_TIME)
def list_shows(params):
    """Build categories listing"""
    shows = []

    if params.next == 'list_shows_1':

        emission_title = 'Émissions'

        shows.append({
            'label': emission_title,
            'url': common.PLUGIN.get_url(
                module_path=params.module_path,
                module_name=params.module_name,
                emission_title=emission_title,
                action='replay_entry',
                next='list_shows_emissions_1',
                window_title=emission_title
            )
        })

        file_path = utils.get_webcontent(URL_CATEGORIES)
        categories_json = json.loads(file_path)

        for category in categories_json["item"]:
            if category["@attributes"]["id"] == 'category':
                for category_sub in category["item"]:
                    if 'category-' in category_sub["@attributes"]["id"]:
                        category_name = category_sub["@attributes"]["name"]
                        category_url = category_sub["@attributes"]["url"]

                        shows.append({
                            'label': category_name,
                            'url': common.PLUGIN.get_url(
                                module_path=params.module_path,
                                module_name=params.module_name,
                                action='replay_entry',
                                category_url=category_url,
                                category_name=category_name,
                                next='list_shows_categories_1',
                                window_title=category_name
                            )
                        })

    elif params.next == 'list_shows_emissions_1':

        file_path = utils.download_catalog(
            URL_EMISSIONS_AUVIO,
            'url_emissions_auvio.html')
        emissions_html = open(file_path).read()
        emissions_soup = bs(emissions_html, 'html.parser')
        list_emissions = emissions_soup.find_all(
            'article', class_="rtbf-media-item col-xxs-12 col-xs-6 col-md-4 col-lg-3 ")

        for emission in list_emissions:

            emission_id = emission.get('data-id')
            emission_title = emission.find('h4').get_text().encode('utf-8')
            list_emission_image = emission.find('img').get('data-srcset').split(' ')
            emission_image = ''
            for image_datas in list_emission_image:
                if 'jpg' in image_datas:
                    if ',' in image_datas:
                        emission_image = image_datas.split(',')[1]
                    else:
                        emission_image = image_datas

            shows.append({
                'label': emission_title,
                'thumb': emission_image,
                'url': common.PLUGIN.get_url(
                    module_path=params.module_path,
                    module_name=params.module_name,
                    emission_title=emission_title,
                    action='replay_entry',
                    emission_id=emission_id,
                    next='list_videos_emission',
                    window_title=emission_title
                )
            })

    elif params.next == 'list_shows_categories_1':
    
        sub_categories_html = utils.get_webcontent(
            params.category_url)
        sub_categories_soup = bs(sub_categories_html, 'html.parser')
        list_sub_categories = sub_categories_soup.find_all(
            'section', class_="js-item-container")

        for sub_category in list_sub_categories:

            sub_category_title = " ".join(sub_category.find('h2').get_text().encode('utf-8').split())
            sub_category_id = sub_category.get('id')

            shows.append({
                'label': sub_category_title,
                'url': common.PLUGIN.get_url(
                    module_path=params.module_path,
                    module_name=params.module_name,
                    sub_category_title=sub_category_title,
                    action='replay_entry',
                    sub_category_id=sub_category_id,
                    category_url=params.category_url,
                    next='list_videos_categorie',
                    window_title=sub_category_title
                )
            })

        list_sub_categories_to_dl = sub_categories_soup.find_all(
            'div', class_=re.compile("js-widget js-widget-"))

        for sub_category_2 in list_sub_categories_to_dl:

            sub_category_data_uuid = sub_category_2.find('b').get('data-uuid')
            sub_categories_2_json = utils.get_webcontent(
                URL_SUB_CATEGORIES % (sub_category_data_uuid, sub_category_data_uuid.split('-')[1]))
            sub_categories_2_jsonparser = json.loads(sub_categories_2_json)
            if sub_category_data_uuid in sub_categories_2_jsonparser["blocks"]:
                sub_categories_2_html = sub_categories_2_jsonparser["blocks"][sub_category_data_uuid]
                sub_categories_2_soup = bs(sub_categories_2_html, 'html.parser')
                list_sub_categories_2 = sub_categories_2_soup.find_all(
                    'section', class_="js-item-container")

                for sub_category_22 in list_sub_categories_2:

                    sub_category_title = " ".join(sub_category_22.find('h2').get_text().encode('utf-8').split())
                    sub_category_id = sub_category_22.get('id')

                    shows.append({
                        'label': sub_category_title,
                        'url': common.PLUGIN.get_url(
                            module_path=params.module_path,
                            module_name=params.module_name,
                            sub_category_title=sub_category_title,
                            action='replay_entry',
                            sub_category_data_uuid=sub_category_data_uuid,
                            sub_category_id=sub_category_id,
                            category_url=params.category_url,
                            next='list_videos_categorie_2',
                            window_title=sub_category_title
                        )
                    })


    return common.PLUGIN.create_listing(
        shows,
        sort_methods=(
            common.sp.xbmcplugin.SORT_METHOD_UNSORTED,
            common.sp.xbmcplugin.SORT_METHOD_LABEL
        ),
        category=common.get_window_title(params)
    )


@common.PLUGIN.mem_cached(common.CACHE_TIME)
def list_videos(params):
    """Build videos listing"""
    videos = []

    if params.next == 'list_videos_emission':

        file_path = utils.download_catalog(
            URL_JSON_EMISSION_BY_ID % params.emission_id,
            'url_videos_emission_%s.html' % params.emission_id)
        videos_json = open(file_path).read()
        videos_jsonparser = json.loads(videos_json)

        for video in videos_jsonparser['data']:

            if video["subtitle"]:
                title = video["title"].encode('utf-8') + \
                    ' - ' + video["subtitle"].encode('utf-8')
            else:
                title = video["title"].encode('utf-8')
            img = URL_ROOT_IMAGE_RTBF + video["thumbnail"]["full_medium"]
            video_id = video["id"]
            plot = ''
            if video["description"]:
                plot = video["description"].encode('utf-8')
            duration = 0
            duration = video["durations"]

            value_date = time.strftime(
                '%d %m %Y', time.localtime(video["liveFrom"]))
            date = str(value_date).split(' ')
            day = date[0]
            mounth = date[1]
            year = date[2]

            date = '.'.join((day, mounth, year))
            aired = '-'.join((year, mounth, day))

            info = {
                'video': {
                    'title': title,
                    'plot': plot,
                    # 'episode': episode_number,
                    # 'season': season_number,
                    # 'rating': note,
                    'aired': aired,
                    'date': date,
                    'duration': duration,
                    'year': year,
                    'mediatype': 'tvshow'
                }
            }

            download_video = (
                common.GETTEXT('Download'),
                'XBMC.RunPlugin(' + common.PLUGIN.get_url(
                    action='download_video',
                    module_path=params.module_path,
                    module_name=params.module_name,
                    video_id=video_id) + ')'
            )
            context_menu = []
            context_menu.append(download_video)

            videos.append({
                'label': title,
                'thumb': img,
                'fanart': img,
                'url': common.PLUGIN.get_url(
                    module_path=params.module_path,
                    module_name=params.module_name,
                    action='replay_entry',
                    next='play_r',
                    video_id=video_id
                ),
                'is_playable': True,
                'info': info,
                'context_menu': context_menu
            })

    elif params.next == 'list_videos_categorie':

        file_path = utils.get_webcontent(params.category_url)
        episodes_soup = bs(file_path, 'html.parser')
        list_categories = episodes_soup.find_all('section', class_="js-item-container")

        for select_category_value in list_categories:
            if select_category_value.get('id') == params.sub_category_id:

                list_episodes = select_category_value.find_all('article')

                for episode in list_episodes:

                    if episode.get('data-type') == 'media':
                        if episode.find('h4'):
                            title = episode.find('h3').find(
                                'a').get('title') + ' - ' + \
                                episode.find('h4').get_text()
                        else:
                            title = episode.find('h3').find('a').get('title')
                        duration = 0
                        video_id = episode.get('data-id')
                        all_images = episode.find('img').get(
                            'data-srcset').split(',')
                        for image in all_images:
                            img = image.split(' ')[0]

                        info = {
                            'video': {
                                'title': title,
                                # 'plot': plot,
                                # 'episode': episode_number,
                                # 'season': season_number,
                                # 'rating': note,
                                # 'aired': aired,
                                # 'date': date,
                                'duration': duration,
                                # 'year': year,
                                'mediatype': 'tvshow'
                            }
                        }

                        download_video = (
                            common.GETTEXT('Download'),
                            'XBMC.RunPlugin(' + common.PLUGIN.get_url(
                                action='download_video',
                                module_path=params.module_path,
                                module_name=params.module_name,
                                video_id=video_id) + ')'
                        )
                        context_menu = []
                        context_menu.append(download_video)

                        videos.append({
                            'label': title,
                            'thumb': img,
                            'fanart': img,
                            'url': common.PLUGIN.get_url(
                                module_path=params.module_path,
                                module_name=params.module_name,
                                action='replay_entry',
                                next='play_r',
                                video_id=video_id
                            ),
                            'is_playable': True,
                            'info': info,
                            'context_menu': context_menu
                        })

    elif params.next == 'list_videos_categorie_2':

        sub_categories_2_json = utils.get_webcontent(
            URL_SUB_CATEGORIES % (params.sub_category_data_uuid, params.sub_category_data_uuid.split('-')[1]))
        sub_categories_2_jsonparser = json.loads(sub_categories_2_json)
        sub_categories_2_html = sub_categories_2_jsonparser["blocks"][params.sub_category_data_uuid]
        sub_categories_2_soup = bs(sub_categories_2_html, 'html.parser')
        list_categories = sub_categories_2_soup.find_all(
            'section', class_="js-item-container")

        for select_category_value in list_categories:
            if select_category_value.get('id') == params.sub_category_id:

                list_episodes = select_category_value.find_all('article')

                for episode in list_episodes:

                    if episode.get('data-type') == 'media':
                        if episode.find('h4'):
                            title = episode.find('h3').find(
                                'a').get('title') + ' - ' + \
                                episode.find('h4').get_text()
                        else:
                            title = episode.find('h3').find('a').get('title')
                        duration = 0
                        video_id = episode.get('data-id')
                        all_images = episode.find('img').get(
                            'data-srcset').split(',')
                        for image in all_images:
                            img = image.split(' ')[0]

                        info = {
                            'video': {
                                'title': title,
                                # 'plot': plot,
                                # 'episode': episode_number,
                                # 'season': season_number,
                                # 'rating': note,
                                # 'aired': aired,
                                # 'date': date,
                                'duration': duration,
                                # 'year': year,
                                'mediatype': 'tvshow'
                            }
                        }

                        download_video = (
                            common.GETTEXT('Download'),
                            'XBMC.RunPlugin(' + common.PLUGIN.get_url(
                                action='download_video',
                                module_path=params.module_path,
                                module_name=params.module_name,
                                video_id=video_id) + ')'
                        )
                        context_menu = []
                        context_menu.append(download_video)

                        videos.append({
                            'label': title,
                            'thumb': img,
                            'fanart': img,
                            'url': common.PLUGIN.get_url(
                                module_path=params.module_path,
                                module_name=params.module_name,
                                action='replay_entry',
                                next='play_r',
                                video_id=video_id
                            ),
                            'is_playable': True,
                            'info': info,
                            'context_menu': context_menu
                        })


    return common.PLUGIN.create_listing(
        videos,
        sort_methods=(
            common.sp.xbmcplugin.SORT_METHOD_UNSORTED,
            common.sp.xbmcplugin.SORT_METHOD_DATE
        ),
        content='tvshows',
        category=common.get_window_title(params)
    )


@common.PLUGIN.mem_cached(common.CACHE_TIME)
def start_live_tv_stream(params):
    lives = []

    title = ''
    # subtitle = ' - '
    plot = ''
    duration = 0
    img = ''
    url_live = ''

    file_path = utils.download_catalog(
        URL_JSON_LIVE % (get_partener_key(params)),
        '%s_live.json' % (params.channel_name))
    live_json = open(file_path).read()
    live_jsonparser = json.loads(live_json)

    # channel_live_in_process = False

    for live in live_jsonparser:

        if type(live["channel"]) is dict:
            live_channel = live["channel"]["label"]
        else:
            live_channel = 'Exclu Auvio'

        start_date_value = format_hours(live["start_date"])
        end_date_value = format_hours(live["end_date"])
        day_value = format_day(live["start_date"])

        title = live_channel + " - [I]" + live["title"] + \
            ' - ' + day_value + ' - ' + start_date_value + \
            '-' + end_date_value + "[/I]"

        url_live = ''
        if "url_streaming" in live:
            url_live = live["url_streaming"]["url_hls"]
        plot = live["description"].encode('utf-8')
        img = live["images"]["illustration"]["16x9"]["1248x702"]

        info = {
            'video': {
                'title': title,
                'plot': plot,
                'duration': duration
            }
        }

        lives.append({
            'label': title,
            'fanart': img,
            'thumb': img,
            'url': common.PLUGIN.get_url(
                action='replay_entry',
                next='play_l',
                module_name=params.module_name,
                module_path=params.module_path,
                url_live=url_live,
            ),
            'is_playable': True,
            'info': info
        })

    return lives


def get_video_url(params):
    """Get video URL and start video player"""
    if params.next == 'play_l':
        if 'drm' in params.url_live:
            return params.url_live.replace('_drm.m3u8', '_aes.m3u8')
        return params.url_live
    elif params.next == 'play_r' or params.next == 'download_video':
        file_path = utils.get_webcontent(
            URL_VIDEO_BY_ID % params.video_id)
        data_stream = re.compile('data-media=\"(.*?)\"').findall(
            file_path)[0]
        data_stream = data_stream.replace('&quot;', '"')
        data_stream_json = json.loads(data_stream)
        url_video = ''
        if data_stream_json["urlHls"] is None:
            if 'youtube.com' in data_stream_json["url"]:
                video_id = data_stream_json["url"].rsplit('/', 1)[1]
                if params.next == 'download_video':
                    return resolver.get_stream_youtube(video_id, True)
                else:
                    return resolver.get_stream_youtube(video_id, False)
            else:
                url_video = data_stream_json["url"]
        else:
            url_video = data_stream_json["urlHls"]
            if 'drm' in url_video:
                # the following url is not drm protected
                url_video = data_stream_json["urlHlsAes128"]
        return url_video
